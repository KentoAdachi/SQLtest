import java.applet.Applet;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



/**
 * @author BP16001
 *
 */
public class MainWindow extends Applet implements ActionListener{
	public void init() {

	}
	public void actionPerformed(ActionEvent event) {

	}
	public void paint(Graphics graphics) {

	}
}
